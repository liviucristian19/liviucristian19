import javax.swing.*;
import java.awt.*;

public class Main extends JFrame{
    private JPanel mainPanel;
    private JButton button1;
    private JTextField textField1;
    private JTextPane textPane1;
    private JComboBox comboBox1;
    private JCheckBox checkBox1;
    private JButton button2;

    public Main()  {
      this.setContentPane(mainPanel);
    }

    public static void main(String[] args) {
        Main f = new Main();

        f.setSize(400,150);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        f.setVisible(true);
    }
}
